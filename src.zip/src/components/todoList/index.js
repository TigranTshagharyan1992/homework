import React from "react";
import './index.css';
import Input from './../elements/input'
import Button from './../elements/button'

class TodoList extends React.Component{

    constructor() {
        super();
        this.state = {
            todo: {id:'',name:''},
            todoList :[],
        }
    }
    setTodo(value){
        this.setState({id:this.state.todoList.length+1,name:value})
    };
    updateTodoList(){
        console.log('in');
    }

    render() {
        return (
            <div className='block'>
                <div style={{justifyContent: 'center'}}>Todo list</div>
                <div className='header'>
                    <Input type='text' value={this.state.todo.name} onChange={(e)=>{this.setTodo(e.target.value)}}> Name of row</Input>
                    <Button onClick{this.updateTodoList}> Add row</Button>
                </div>

            </div>
        )
    }

}

export default TodoList;